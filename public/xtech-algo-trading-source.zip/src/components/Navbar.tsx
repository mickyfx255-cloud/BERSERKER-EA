import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Terminal, Shield, User, Menu, X, ArrowUpRight, Coins, Sparkles, LayoutDashboard, Download } from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  navigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, navigate }) => {
  const { user, isAdmin } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    if (currentPath !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#d4af37]/20 bg-[#090a0d]/95 shadow-md shadow-black/40 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Brand / Logo - White with restrained gold accents */}
        <div 
          onClick={() => navigate('/')} 
          className="group flex cursor-pointer items-center space-x-3 transition-opacity"
        >
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-[#d4af37]/50 bg-[#121319] shadow-[0_0_15px_rgba(212,175,55,0.18)] group-hover:border-[#ffd700] transition-colors">
            <span className="font-black text-xl tracking-tighter text-[#ffd700]">
              X
            </span>
            <div className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-[#d4af37] shadow-[0_0_8px_#ffd700]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-black tracking-tight text-base sm:text-lg uppercase text-white group-hover:text-neutral-100 transition-colors flex items-center">
                <span className="text-[#ffd700]">X</span>
                <span className="text-white">TECH</span>
                <span className="text-xs font-semibold text-neutral-300 tracking-wider ml-1.5 hidden sm:inline">ALGO TRADING</span>
              </span>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded border border-[#d4af37]/35 bg-[#171822] text-[#f5d061] font-semibold">
                MT4 &amp; MT5
              </span>
            </div>
            <p className="text-[9px] sm:text-[10px] font-mono tracking-widest text-[#d4af37] font-semibold uppercase">
              AUTOMATE. ADAPT. OUTPERFORM.
            </p>
          </div>
        </div>

        {/* Desktop Nav Anchors */}
        <nav className="hidden md:flex items-center space-x-7 text-xs font-semibold text-neutral-300">
          <button 
            onClick={() => scrollToSection('product')} 
            className="hover:text-white transition-colors cursor-pointer"
          >
            EA Suite
          </button>
          <button 
            onClick={() => scrollToSection('how')} 
            className="hover:text-white transition-colors cursor-pointer"
          >
            How it Works
          </button>
          <button 
            onClick={() => scrollToSection('platform')} 
            className="hover:text-white transition-colors cursor-pointer"
          >
            Terminal Specs
          </button>
          <button 
            onClick={() => scrollToSection('advisor')} 
            className="flex items-center space-x-1.5 text-emerald-400 hover:text-white transition-colors cursor-pointer"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>AI Advisor</span>
          </button>
          <button 
            onClick={() => scrollToSection('mentorship')} 
            className="hover:text-white transition-colors cursor-pointer"
          >
            Mentorship
          </button>
          <button 
            onClick={() => scrollToSection('contact')} 
            className="hover:text-white transition-colors cursor-pointer"
          >
            Contact
          </button>
        </nav>

        {/* Action Controls - Direct Client Desk & Admin, No Login Hurdles */}
        <div className="hidden lg:flex items-center space-x-3">
          <button
            onClick={() => navigate('/admin')}
            className="flex items-center space-x-1.5 rounded-lg border border-[#d4af37]/30 bg-[#14151c] px-3 py-1.5 text-xs font-mono font-medium text-neutral-300 hover:text-white hover:border-[#d4af37]/60 transition-all cursor-pointer"
          >
            <Terminal className="h-3.5 w-3.5 text-[#d4af37]" />
            <span>Admin Desk</span>
          </button>

          <button
            onClick={() => navigate('/dashboard')}
            className="gold-btn flex items-center space-x-1.5 rounded-lg px-4 py-2 text-xs font-extrabold uppercase tracking-wider cursor-pointer shadow-sm hover:brightness-105"
          >
            <LayoutDashboard className="h-3.5 w-3.5 text-black" />
            <span>Client Portal</span>
          </button>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex md:hidden items-center space-x-2">
          <button
            onClick={() => navigate('/dashboard')}
            className="text-[11px] font-bold text-black bg-gradient-to-r from-[#d4af37] to-[#f5d061] px-2.5 py-1 rounded"
          >
            Client Desk
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-neutral-300 hover:text-white cursor-pointer"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6 text-[#d4af37]" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#d4af37]/20 bg-[#0d0e13] px-4 pt-3 pb-6 space-y-3 shadow-2xl">
          <button
            onClick={() => scrollToSection('product')}
            className="block w-full text-left py-2 text-sm font-medium text-neutral-200 hover:text-white"
          >
            EA Suite (Berserker Scalp AI &amp; Snxperbot)
          </button>
          <button
            onClick={() => scrollToSection('how')}
            className="block w-full text-left py-2 text-sm font-medium text-neutral-200 hover:text-white"
          >
            How it Works
          </button>
          <button
            onClick={() => scrollToSection('platform')}
            className="block w-full text-left py-2 text-sm font-medium text-neutral-200 hover:text-white"
          >
            MT4 &amp; MT5 Platform Specs
          </button>
          <button
            onClick={() => scrollToSection('advisor')}
            className="block w-full text-left py-2 text-sm font-bold text-emerald-400"
          >
            AI Trading Advisor
          </button>
          <button
            onClick={() => scrollToSection('mentorship')}
            className="block w-full text-left py-2 text-sm font-medium text-neutral-200 hover:text-white"
          >
            Community Mentorship
          </button>
          <button
            onClick={() => scrollToSection('contact')}
            className="block w-full text-left py-2 text-sm font-medium text-neutral-200 hover:text-white"
          >
            Contact &amp; Support Desk
          </button>

          <div className="pt-3 border-t border-neutral-800 flex flex-col space-y-2">
            <button
              onClick={() => { setMobileMenuOpen(false); navigate('/dashboard'); }}
              className="w-full py-2.5 text-center text-xs font-extrabold uppercase rounded gold-btn"
            >
              Open Client Portal
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); navigate('/admin'); }}
              className="w-full py-2 text-center text-xs font-medium uppercase rounded border border-neutral-800 bg-[#121319] text-neutral-300"
            >
              Admin Operations Desk
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
