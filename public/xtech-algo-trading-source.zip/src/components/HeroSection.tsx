import React from 'react';
import tradingWorkstationHero from '../assets/images/hero_trading_workstation_1791724696774.jpg';
import { ShieldCheck, MessageCircle, Bot, ArrowRight, Activity, Cpu, Sparkles, CheckCircle2, TrendingUp, Zap, BarChart2 } from 'lucide-react';

interface HeroSectionProps {
  onViewProduct: () => void;
  onAskAI: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onViewProduct, onAskAI }) => {
  const whatsappUrl = `https://wa.me/255610366248?text=${encodeURIComponent(
    'Hello XTech Algo Trading, I want to inquire about purchasing your Expert Advisor trading systems for MetaTrader 4 & MetaTrader 5.'
  )}`;

  return (
    <section className="relative min-h-[92vh] w-full flex items-center justify-center overflow-hidden bg-transparent border-b border-[#d4af37]/20">
      {/* Ambient deep charcoal glow */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-[#090a0d]/95 via-[#090a0d]/85 to-transparent md:w-3/4" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#090a0d] via-transparent to-transparent" />
      </div>

      {/* Main Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Heading & Copy (White with restrained gold accents) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Top Tag */}
            <div className="flex items-center space-x-3">
              <span className="font-mono text-xs sm:text-sm font-extrabold uppercase tracking-[0.25em] text-[#ffd700]">
                EXPERT ADVISOR TRADING
              </span>
              <span className="hidden sm:inline-block h-1 w-8 bg-gradient-to-r from-[#d4af37] to-neutral-700 rounded-full" />
              <span className="hidden sm:inline-block text-[11px] font-mono text-neutral-400 font-bold">
                MT4 &amp; MT5 ARCHITECTURE
              </span>
            </div>

            {/* Brand Title: White with restrained gold accents */}
            <div className="space-y-1">
              <div className="flex items-baseline flex-wrap gap-x-3">
                {/* Stylized X Icon */}
                <div className="relative inline-flex items-center justify-center h-14 w-14 sm:h-18 sm:w-18 md:h-20 md:w-20 rounded-2xl bg-[#121319] border border-[#d4af37]/60 shadow-[0_0_25px_rgba(212,175,55,0.2)] shrink-0 self-center">
                  <span className="font-black text-3xl sm:text-4xl md:text-5xl text-[#ffd700] select-none">
                    X
                  </span>
                  <div className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-[#d4af37] shadow-[0_0_10px_#ffd700]" />
                </div>

                {/* TECH in crisp white */}
                <span className="font-black uppercase tracking-tight text-5xl sm:text-7xl md:text-8xl text-white leading-none">
                  TECH
                </span>
              </div>

              {/* ALGO TRADING in clean white */}
              <div className="font-black uppercase tracking-tight text-3xl sm:text-5xl md:text-6xl text-white leading-none pt-1">
                ALGO TRADING
              </div>
            </div>

            {/* Official Slogan in restrained gold */}
            <div className="pt-2">
              <span className="font-mono text-base sm:text-xl md:text-2xl font-black tracking-wider text-[#d4af37] block uppercase">
                AUTOMATE. ADAPT. OUTPERFORM.
              </span>
              
              {/* White primary description */}
              <p className="mt-2 text-sm sm:text-base text-neutral-300 font-normal leading-relaxed max-w-xl">
                Advanced Expert Advisor trading systems designed for precision, consistency and real market performance across <strong className="text-white font-semibold">MetaTrader 4 &amp; MetaTrader 5</strong>.
              </p>
            </div>

            {/* Dark charcoal spec pills with gold icons & subtle borders */}
            <div className="flex flex-wrap gap-2.5 font-mono text-xs text-neutral-300 pt-1">
              <div className="flex items-center space-x-2 bg-[#121319] px-3.5 py-2 rounded-xl border border-[#d4af37]/25 shadow-xs">
                <Cpu className="h-3.5 w-3.5 text-[#ffd700]" />
                <span className="font-medium text-white">Dual MT4 &amp; MT5 Engines</span>
              </div>
              <div className="flex items-center space-x-2 bg-[#121319] px-3.5 py-2 rounded-xl border border-[#d4af37]/25 shadow-xs">
                <Activity className="h-3.5 w-3.5 text-[#ffd700]" />
                <span className="font-medium text-white">Gold (XAUUSD) &amp; Major Forex</span>
              </div>
              <div className="flex items-center space-x-2 bg-[#121319] px-3.5 py-2 rounded-xl border border-[#d4af37]/25 shadow-xs">
                <ShieldCheck className="h-3.5 w-3.5 text-[#ffd700]" />
                <span className="text-emerald-400 font-bold">Hard Stop Loss · Zero Martingale</span>
              </div>
            </div>

            {/* CTAs: Gold with black text */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5">
              {/* Primary: Gold button with black text */}
              <button
                onClick={onViewProduct}
                className="gold-btn group inline-flex items-center justify-center space-x-2 rounded-xl px-7 py-4 text-xs font-extrabold uppercase tracking-wider cursor-pointer shadow-lg hover:brightness-105"
              >
                <span>Explore Expert Advisors</span>
                <ArrowRight className="h-4 w-4 text-black group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Direct WhatsApp Inquire */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center space-x-2 rounded-xl border border-[#d4af37]/35 bg-[#14151c] px-6 py-4 text-xs font-bold text-white hover:border-[#ffd700] hover:bg-[#191b24] transition-all shadow-xs"
              >
                <MessageCircle className="h-4 w-4 text-emerald-400" />
                <span>Inquire via WhatsApp</span>
              </a>

              {/* Ask AI Advisor */}
              <button
                onClick={onAskAI}
                className="gold-outline-btn inline-flex items-center justify-center space-x-2 rounded-xl px-5 py-4 text-xs cursor-pointer shadow-xs"
              >
                <Bot className="h-4 w-4 text-[#ffd700]" />
                <span>Ask AI Advisor</span>
              </button>
            </div>

            {/* Reassurance strip */}
            <div className="flex items-center space-x-3 text-xs text-neutral-400 font-mono pt-1">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              <span className="text-neutral-300">Official Institutional Release</span>
              <span>·</span>
              <span className="text-neutral-300">Prop Firm Ready</span>
              <span>·</span>
              <span>Desk: +255 610 366 248</span>
            </div>

          </div>

          {/* Right Column: Premium Trading Workstation Imagery against Dark Background */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative group w-full max-w-lg aspect-[16/10] sm:aspect-[4/3] rounded-3xl overflow-hidden border border-[#d4af37]/35 shadow-[0_20px_60px_rgba(0,0,0,0.85)] bg-[#0d0e14]">
              
              {/* Premium Trading Workstation Photo */}
              <img
                src={tradingWorkstationHero}
                alt="XTech Institutional Trading Workstation"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />

              {/* Top Ambient Badges */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                <div className="flex items-center space-x-1.5 rounded-full bg-black/85 backdrop-blur-md px-3 py-1 border border-[#d4af37]/50 shadow-md">
                  <Sparkles className="h-3 w-3 text-[#ffd700]" />
                  <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-[#ffd700]">
                    AI WORKSTATION
                  </span>
                </div>
                <div className="rounded-full bg-black/85 backdrop-blur-md px-2.5 py-1 border border-neutral-700">
                  <span className="font-mono text-[10px] font-bold text-white">
                    MT4 &amp; MT5 ENGINE
                  </span>
                </div>
              </div>

              {/* Bottom Institutional Terminal Banner with Candlestick Indicators */}
              <div className="absolute bottom-4 left-4 right-4 rounded-2xl bg-[#0d0e14]/92 backdrop-blur-md p-3.5 border border-[#d4af37]/30 text-white space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs uppercase tracking-tight text-white flex items-center space-x-1.5">
                    <span className="text-[#ffd700]">X</span>
                    <span>TECH</span>
                    <span className="text-neutral-300">EXECUTION DESK</span>
                  </span>
                  <div className="flex items-center space-x-1 text-[10px] font-mono text-emerald-400 font-bold">
                    <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                    <span>ONLINE</span>
                  </div>
                </div>

                {/* Candlestick Visualization Bar with Green & Red Candles */}
                <div className="py-1 px-2 rounded-lg bg-black/70 border border-neutral-800/80 flex items-center justify-between">
                  <div className="flex items-center space-x-1.5 text-[10px] font-mono text-neutral-300">
                    <BarChart2 className="h-3.5 w-3.5 text-[#ffd700]" />
                    <span>XAUUSD M5 Terminal</span>
                  </div>
                  {/* Candle preview bars */}
                  <div className="flex items-center space-x-1 h-4">
                    <span className="w-1.5 h-3 bg-emerald-500 rounded-xs" />
                    <span className="w-1.5 h-4 bg-emerald-500 rounded-xs" />
                    <span className="w-1.5 h-2 bg-red-500 rounded-xs" />
                    <span className="w-1.5 h-3.5 bg-emerald-500 rounded-xs" />
                    <span className="w-1.5 h-1.5 bg-red-500 rounded-xs" />
                    <span className="w-1.5 h-4 bg-emerald-500 rounded-xs" />
                  </div>
                </div>

                {/* Candlestick Terminal Stats (Green & Red accents) */}
                <div className="grid grid-cols-3 gap-2 pt-1 border-t border-neutral-800 text-center font-mono">
                  <div className="bg-black/60 rounded p-1">
                    <span className="text-[9px] text-neutral-400 block">Win Rate</span>
                    <span className="text-xs font-bold text-emerald-400">84.7% ▲</span>
                  </div>
                  <div className="bg-black/60 rounded p-1">
                    <span className="text-[9px] text-neutral-400 block">Profit Factor</span>
                    <span className="text-xs font-bold text-[#ffd700]">2.82</span>
                  </div>
                  <div className="bg-black/60 rounded p-1">
                    <span className="text-[9px] text-neutral-400 block">Max DD</span>
                    <span className="text-xs font-bold text-red-400">3.8% ▼</span>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
