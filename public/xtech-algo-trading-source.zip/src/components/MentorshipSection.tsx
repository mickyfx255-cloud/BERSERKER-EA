import React from 'react';
import { Play, Video, Users, Award, MessageCircle, Mail } from 'lucide-react';

export const MentorshipSection: React.FC = () => {
  return (
    <section id="mentorship" className="relative py-24 bg-[#090a0d]/90 border-t border-[#d4af37]/20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="font-mono text-xs font-bold uppercase tracking-wider text-[#ffd700]">
            XTECH TRADING ACADEMY
          </span>
          <h2 className="mt-2 font-extrabold uppercase tracking-tight text-3xl sm:text-4xl text-white">
            COMMUNITY MENTORSHIP &amp; VIDEO BRIEFING
          </h2>
          <p className="mt-3 text-sm text-neutral-300 font-sans">
            Learn the institutional trading principles behind Berserker Scalp AI &amp; Snxperbot Adaptive Engine across MetaTrader 4 and MetaTrader 5.
          </p>
        </div>

        {/* Video & Info Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* YouTube Video Embed */}
          <div className="lg:col-span-7">
            <div className="relative aspect-video rounded-3xl overflow-hidden border border-[#d4af37]/40 shadow-[0_16px_50px_rgba(0,0,0,0.85)] bg-black">
              <iframe
                className="w-full h-full"
                src="https://www.youtube-nocookie.com/embed/P_kzXAeqECE"
                title="XTech Algo Trading Mentorship Video"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            </div>
            <div className="mt-3 flex items-center justify-between text-xs font-mono text-neutral-400">
              <span>OFFICIAL XTECH VIDEO ARCHIVE</span>
              <span>VIDEO ID: P_kzXAeqECE</span>
            </div>
          </div>

          {/* Mentorship Points */}
          <div className="lg:col-span-5 space-y-6">
            <div className="rounded-2xl p-6 border border-[#d4af37]/25 bg-[#111218] shadow-md">
              <div className="flex items-center space-x-3 mb-3">
                <div className="h-10 w-10 rounded-xl bg-[#171822] border border-[#d4af37]/30 flex items-center justify-center">
                  <Award className="h-5 w-5 text-[#ffd700]" />
                </div>
                <h3 className="text-base font-bold uppercase text-white">
                  VIP Algorithmic Mentorship
                </h3>
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                Receive direct guidance from the creators of XTech trading systems. Learn how to calibrate parameters for changing market volatility regimes and pass prop firm challenges with confidence.
              </p>
            </div>

            <div className="rounded-2xl p-6 border border-[#d4af37]/25 bg-[#111218] shadow-md">
              <div className="flex items-center space-x-3 mb-3">
                <div className="h-10 w-10 rounded-xl bg-[#171822] border border-[#d4af37]/30 flex items-center justify-center">
                  <Users className="h-5 w-5 text-[#ffd700]" />
                </div>
                <h3 className="text-base font-bold uppercase text-white">
                  Elite VIP Community (@XtechTrades)
                </h3>
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                Connect with serious algorithmic traders running XTech systems worldwide on MT4 &amp; MT5. Access verified set files, broker spread audits, and London VPS low-ping setups.
              </p>
            </div>

            {/* Quick Action */}
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="https://wa.me/255610366248?text=Hello%20XTech%20Algo%20Trading,%20I%20would%20like%20to%20apply%20for%20the%20Mentorship%20Program."
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 gold-btn rounded-xl p-3.5 text-center text-xs font-extrabold uppercase shadow-md hover:brightness-105"
              >
                Inquire via WhatsApp
              </a>
              <a
                href="https://t.me/XtechTrades"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 rounded-xl border border-[#d4af37]/35 bg-[#14151e] p-3.5 text-center text-xs font-bold text-white hover:border-[#ffd700] hover:bg-[#1a1b24] transition-colors shadow-xs"
              >
                Join Telegram
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
